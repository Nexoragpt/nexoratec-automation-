# NexoraTec — paquete de despliegue (fase de motor local)

Este repositorio es una base técnica ejecutable, **no una instalación en producción**. No contiene una integración terminada de generación automática de guiones, investigación web, OAuth de YouTube ni publicación. No debe anunciarse como autónomo hasta completar y probar esas piezas.

## Requisitos

- Ubuntu 22.04/24.04 ARM64 o x86_64.
- Docker Engine y Docker Compose plugin.
- Para producción: servidor accesible y persistente. La disponibilidad de planes gratuitos depende del proveedor y no está garantizada.
- Para publicar: proyecto de Google Cloud/YouTube Data API y autorización OAuth del propietario del canal. No guardar contraseñas de Google; usar OAuth y proteger el token.

## Qué incluye

- API FastAPI con health check y registro SQLite de trabajos.
- Renderizador offline de vídeos verticales MP4 (1080x1920) a partir de un guion ya escrito.
- Voz sintética local mediante eSpeak y composición de vídeo con FFmpeg.
- Docker Compose con reinicio automático del contenedor.
- Publicación automática desactivada por defecto.

## Qué NO incluye todavía

- Descubrimiento y verificación automática de temas/fuentes.
- Redacción factual automatizada con citas y control de alucinaciones.
- Generación visual avanzada; el renderizador actual usa tarjetas tipográficas.
- Flujo de aprobación editorial, detección de duplicados y pruebas de calidad completas.
- Integración YouTube OAuth, subida, programación y lectura de Analytics.
- Monitorización externa, copias de seguridad remotas o garantía de disponibilidad.

## Renderizar una demo (sin APIs de pago)

En Ubuntu con Python, FFmpeg y eSpeak instalados:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/render_demo.py
```

El resultado se guarda en `storage/videos/demo-nexoratec.mp4`.

## Despliegue Docker

```bash
cp .env.example .env
chmod 600 .env
# Revisa .env: AUTO_PUBLISH debe seguir en false.
docker compose -f deploy/compose.yaml up -d --build
curl http://127.0.0.1:8000/health
```

La API queda enlazada a localhost. No expongas el puerto 8000 directamente a Internet; usa un proxy TLS y autenticación antes de cualquier acceso remoto.

## Regla de coste cero

No habilitar facturación, instancias de pago, almacenamiento de pago, dominios de pago ni APIs de generación con coste. Un nivel gratuito no es una garantía contractual de coste cero perpetuo. Si un proveedor exige tarjeta o activar facturación para continuar, detén el despliegue y busca una alternativa local; no cambies a pago.

## Estado real

La carpeta y el ZIP son artefactos preparados en el entorno de desarrollo. **No están desplegados en una cuenta cloud ni conectados a YouTube.** La producción solo se puede declarar cuando un servidor real responda al health check, el proceso sobreviva a un reinicio, se produzca un Short de prueba y la subida privada/no listada se valide mediante OAuth.
