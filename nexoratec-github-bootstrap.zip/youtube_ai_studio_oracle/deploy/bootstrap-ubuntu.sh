#!/usr/bin/env bash
set -euo pipefail

# Run on a fresh Ubuntu ARM64 Oracle VM as the default ubuntu user.
sudo apt-get update
sudo apt-get install -y ca-certificates curl
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"

echo
echo "Docker installed. Log out and reconnect, then deploy:"
echo "  cd ~/youtube-ai-studio"
echo "  cp .env.example .env && chmod 600 .env"
echo "  docker compose -f deploy/compose.yaml up -d --build"
