"""Offline, no-API vertical Short renderer using espeak and FFmpeg.

This renders an authored script. It deliberately does not invent factual scripts or
fetch copyrighted media. A later research/script stage must supply verified text.
"""
from __future__ import annotations

import math
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont

W, H = 1080, 1920
BG = (9, 16, 32)
ACCENT = (66, 211, 255)
WHITE = (245, 248, 255)
MUTED = (165, 180, 205)


def _bin(name: str) -> str:
    found = shutil.which(name)
    if not found:
        raise RuntimeError(f"Required executable not found: {name}")
    return found


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def _wrap(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _sentences(script: str) -> list[str]:
    chunks = [x.strip() for x in re.split(r"(?<=[.!?])\s+|\n+", script) if x.strip()]
    # Keep caption cards readable; split long sentences into short phrase groups.
    result: list[str] = []
    for chunk in chunks:
        words = chunk.split()
        while len(words) > 11:
            result.append(" ".join(words[:10]))
            words = words[10:]
        if words:
            result.append(" ".join(words))
    return result


def _draw_frame(title: str, caption: str, index: int, total: int, path: Path) -> None:
    img = Image.new("RGB", (W, H), BG)
    px = img.load()
    # Subtle diagonal gradient made locally; no stock assets or network calls.
    for y in range(H):
        t = y / H
        c = (int(8 + 8*t), int(15 + 10*t), int(31 + 25*t))
        for x in range(W):
            px[x, y] = c
    d = ImageDraw.Draw(img)
    # Decorative technical grid and accent rails.
    for x in range(0, W, 90):
        d.line((x, 0, x, H), fill=(18, 34, 55), width=1)
    for y in range(0, H, 90):
        d.line((0, y, W, y), fill=(18, 34, 55), width=1)
    d.rounded_rectangle((68, 105, 1012, 1815), radius=42, outline=(34, 65, 91), width=3)
    d.rounded_rectangle((110, 145, 970, 160), radius=7, fill=ACCENT)
    brand_font = _font(38, True)
    title_font = _font(54, True)
    caption_font = _font(78, True)
    small_font = _font(30)
    d.text((115, 205), "NEXORATEC  /  TECNOLOGÍA EN 45s", font=brand_font, fill=ACCENT)
    title_lines = _wrap(d, title, title_font, 820)[:3]
    ty = 340
    for line in title_lines:
        d.text((115, ty), line, font=title_font, fill=WHITE)
        ty += 72
    # Caption panel
    panel = (105, 760, 975, 1390)
    d.rounded_rectangle(panel, radius=34, fill=(16, 31, 52), outline=(49, 91, 119), width=3)
    lines = _wrap(d, caption, caption_font, 740)
    line_height = 105
    total_h = len(lines) * line_height
    cy = panel[1] + (panel[3] - panel[1] - total_h) // 2
    for line in lines:
        bbox = d.textbbox((0, 0), line, font=caption_font)
        d.text(((W - (bbox[2]-bbox[0]))//2, cy), line, font=caption_font, fill=WHITE)
        cy += line_height
    # Progress indicator
    d.rounded_rectangle((115, 1685, 965, 1702), radius=8, fill=(38, 56, 78))
    prog_w = int(850 * (index + 1) / max(total, 1))
    d.rounded_rectangle((115, 1685, 115 + prog_w, 1702), radius=8, fill=ACCENT)
    d.text((115, 1735), "NEXORATEC", font=small_font, fill=MUTED)
    d.text((850, 1735), f"{index+1:02d} / {total:02d}", font=small_font, fill=MUTED)
    img.save(path, quality=94)


def render_short(title: str, script: str, output: str | Path, voice: str = "es", max_seconds: int = 59) -> Path:
    """Render a 1080x1920 MP4. Requires ffmpeg, ffprobe and espeak-ng/espeak."""
    if len(title.strip()) < 3 or len(script.strip()) < 30:
        raise ValueError("Provide a title and a script of at least 30 characters")
    if len(script) > 5000:
        raise ValueError("Script is too long; keep a Short concise")
    ffmpeg, ffprobe, espeak = _bin("ffmpeg"), _bin("ffprobe"), _bin("espeak")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    captions = _sentences(script)
    if not captions:
        raise ValueError("Script contains no renderable text")
    with tempfile.TemporaryDirectory(prefix="nexoratec-") as td:
        work = Path(td)
        audio = work / "voice.wav"
        subprocess.run([espeak, "-v", voice, "-s", "158", "-w", str(audio), script], check=True, capture_output=True)
        probe = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(audio)], check=True, capture_output=True, text=True)
        audio_duration = float(probe.stdout.strip())
        if audio_duration > max_seconds:
            raise ValueError(f"Narration is {audio_duration:.1f}s; limit is {max_seconds}s")
        weights = [max(1, len(x.split())) for x in captions]
        total_weight = sum(weights)
        durations = [audio_duration * w / total_weight for w in weights]
        # Add a small visual tail to avoid cutting the final phoneme.
        durations[-1] += 0.25
        concat = work / "frames.txt"
        with concat.open("w", encoding="utf-8") as f:
            for i, caption in enumerate(captions):
                frame = work / f"frame_{i:03d}.jpg"
                _draw_frame(title, caption, i, len(captions), frame)
                f.write(f"file '{frame.as_posix()}'\n")
                f.write(f"duration {durations[i]:.4f}\n")
            f.write(f"file '{(work / f'frame_{len(captions)-1:03d}.jpg').as_posix()}'\n")
        subprocess.run([
            ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(concat),
            "-i", str(audio), "-vf", "fps=30,format=yuv420p", "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "24", "-c:a", "aac", "-b:a", "128k", "-shortest", "-movflags", "+faststart", str(output)
        ], check=True, capture_output=True)
    return output
