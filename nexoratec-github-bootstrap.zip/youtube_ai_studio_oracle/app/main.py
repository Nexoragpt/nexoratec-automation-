from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.config import settings
from app.database import Base, engine, get_db
from app.models import VideoJob
from app.schemas import JobCreate, JobRead

Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="0.2.0",
              description="Cloud control plane. AI generation and YouTube publishing are not enabled yet.")

@app.get("/health")
def health():
    return {"status": "ok", "environment": settings.environment, "auto_publish": settings.auto_publish}

@app.post("/api/jobs", response_model=JobRead, status_code=201)
def create_job(payload: JobCreate, db: Session = Depends(get_db)):
    job = VideoJob(topic=payload.topic, language=payload.language,
                   target_duration_seconds=payload.target_duration_seconds)
    db.add(job)
    db.commit()
    db.refresh(job)
    return job

@app.get("/api/jobs", response_model=list[JobRead])
def list_jobs(limit: int = 50, db: Session = Depends(get_db)):
    limit = max(1, min(limit, 200))
    return list(db.scalars(select(VideoJob).order_by(VideoJob.id.desc()).limit(limit)))

@app.get("/api/jobs/{job_id}", response_model=JobRead)
def get_job(job_id: int, db: Session = Depends(get_db)):
    job = db.get(VideoJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
