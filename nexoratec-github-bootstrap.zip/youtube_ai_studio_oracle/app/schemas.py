from datetime import datetime
from pydantic import BaseModel, Field

class JobCreate(BaseModel):
    topic: str = Field(min_length=3, max_length=240)
    language: str = Field(default="es", min_length=2, max_length=12)
    target_duration_seconds: int = Field(default=45, ge=10, le=180)

class JobRead(BaseModel):
    id: int
    status: str
    topic: str
    language: str
    target_duration_seconds: int
    title: str | None
    script: str | None
    video_path: str | None
    youtube_video_id: str | None
    error_message: str | None
    created_at: datetime
    model_config = {"from_attributes": True}
