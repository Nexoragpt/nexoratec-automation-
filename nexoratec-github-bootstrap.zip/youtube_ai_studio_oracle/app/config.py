from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "YouTube AI Studio"
    environment: str = "production"
    database_url: str = "sqlite:////app/data/youtube_ai_studio.db"
    storage_dir: Path = Path("/app/storage")
    default_language: str = "es"
    target_shorts_per_day: int = 3
    default_visibility: str = "private"
    auto_publish: bool = False
    openai_api_key: str | None = None
    youtube_client_secrets_file: str | None = None
    youtube_token_file: str = "/app/secrets/youtube-token.json"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
settings.storage_dir.mkdir(parents=True, exist_ok=True)
(settings.storage_dir / "videos").mkdir(parents=True, exist_ok=True)
(settings.storage_dir / "assets").mkdir(parents=True, exist_ok=True)
