from datetime import datetime, timezone
from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.database import Base

def utcnow():
    return datetime.now(timezone.utc)

class VideoJob(Base):
    __tablename__ = "video_jobs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    status: Mapped[str] = mapped_column(String(32), default="idea", index=True)
    topic: Mapped[str] = mapped_column(String(240))
    language: Mapped[str] = mapped_column(String(12), default="es")
    target_duration_seconds: Mapped[int] = mapped_column(Integer, default=45)
    title: Mapped[str | None] = mapped_column(String(100), nullable=True)
    script: Mapped[str | None] = mapped_column(Text, nullable=True)
    video_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    youtube_video_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
