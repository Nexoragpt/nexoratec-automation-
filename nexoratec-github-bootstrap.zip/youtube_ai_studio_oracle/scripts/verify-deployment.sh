#!/usr/bin/env bash
set -euo pipefail
echo "Checking local API health..."
curl --fail --silent http://127.0.0.1:8000/health
echo
echo "Checking Docker Compose services..."
docker compose -f deploy/compose.yaml ps
