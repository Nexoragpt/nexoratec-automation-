#!/usr/bin/env python3
"""Render a demo Short locally without paid APIs or external media."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.services.renderer import render_short

p = argparse.ArgumentParser()
p.add_argument('--title', default='El truco detrás del Wi-Fi')
p.add_argument('--script', default='Tu Wi-Fi no es magia. Tu router convierte los datos en ondas de radio.\nEsas ondas viajan por el aire y tu móvil las transforma otra vez en información.\nPor eso una pared, la distancia o las interferencias pueden debilitar la señal.\nLa próxima vez que falle tu conexión, quizá el problema no sea internet: puede ser la señal.')
p.add_argument('--output', default='storage/videos/demo-nexoratec.mp4')
args = p.parse_args()
path = render_short(args.title, args.script, args.output)
print(f'Rendered: {path}')
